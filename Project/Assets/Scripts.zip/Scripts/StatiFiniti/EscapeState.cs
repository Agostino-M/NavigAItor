using UnityEngine;

public class EscapeState : State
{
    // Riferimento al controller del robot
    private RobotController robotController;

    // Direzione in cui scappare (calcolata come opposta alla posizione del nemico)
    private Vector3 escapeDirection;

    // Flag per indicare se l'escape è completato
    private bool escapeComplete = false;

    // Distanza minima di sicurezza per considerare il robot al sicuro
    private float safeDistance = 5f;

    public EscapeState(StateMachine stateMachine) : base(stateMachine)
    {
        robotController = stateMachine.gameObject.GetComponent<RobotController>();
    }

    public override void EnterState()
    {
        Debug.Log("Entered the ESCAPE state! Robot is escaping from enemy...");

        // Calcola la direzione di fuga:
        // Se è stato rilevato un nemico, calcola la direzione opposta
        if (robotController.enemyDetected)
        {
            // Assumiamo che robotController.enemyPosition sia la posizione del nemico
            escapeDirection = (robotController.transform.position - robotController.enemyPosition).normalized;
        }
        else
        {
            // Se non conosciamo la posizione del nemico, scegli una direzione di default (ad es. verso il retro)
            escapeDirection = Vector3.back;
        }

        robotController.SetMoving(true);
    }

    public override void ExecuteState()
    {
        // Calcola la posizione target in direzione della fuga
        Vector3 targetPosition = robotController.transform.position + escapeDirection;

        // Ruota verso il target
        bool rotated = robotController.RotateToTarget(targetPosition);
        if (rotated)
        {
            // Muove il robot verso il target
            bool moved = robotController.MoveToTarget(targetPosition);
            if (moved)
            {
                Debug.Log("Escaping... moved to position: " + targetPosition);
            }
        }

        // Verifica se il robot è a distanza di sicurezza dal nemico
        // oppure se il nemico non è più rilevato
        if (robotController.enemyDetected)
        {
            float distanceFromEnemy = Vector3.Distance(robotController.transform.position, robotController.enemyPosition);
            if (distanceFromEnemy > safeDistance)
            {
                escapeComplete = true;
            }
        }
        else
        {
            escapeComplete = true;
        }

        // Se la fuga è completata, passa a un altro stato (ad esempio, ricalcola il percorso)
        if (escapeComplete)
        {
            stateMachine.SetState(new PlanningState(stateMachine));
        }
    }

    public override void ExitState()
    {
        robotController.SetMoving(false);
        Debug.Log("Exited the ESCAPE state!");
        // Resetta la flag del nemico (se necessario)
        robotController.enemyDetected = false;
    }
}
